
*****************************************************************============********************************************************
================================================================ |  ReadMe  |==========================================================
*****************************************************************============*********************************************************
 
- Groupe :

	Projet : 		Application mobile 'location de voiture'
	Développeur : 		Anis MEZRAG.
	Groupe de projet : 	MEZRAG-ALILI-MAHDI.

**************************************************************************************************************************************
- Fichiers fournis dossier application mobile :

			- Fichier code source ' Java - XML - PHP '
			- Guide d'utilisation ' PDF '.
			- Rapport ' PDF '. 
			- Readme ' txt '.

**************************************************************************************************************************************
 - Utilisation :

			- Pour utiliser l'application, un guide est fournis et vous avez qu'a suivre les étapes dans l'ordre indiquer.
				* Installer l'application qui se trouve dans le dossier : ~ exe > locationdevoiture.apk.

 			- Pour plus d'informations sur le fonctionnement et les algorythmes, consultez le rapport de projet.

**************************************************************************************************************************************
 - Contact :
		
	* Pour tout contact et informations supplimentaire, veuillez nous adresser un mail à cette adresse : anisjob@hotmail.com	 
