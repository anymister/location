package com.anisapp.locationdevoiture;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Confirmation extends AppCompatActivity {
private Button confimer;
    private EditText name,email,password,c_password;

    private static String URL_RESERV="https://locationwordpress.000webhostapp.com/sitePHP/appli/reservation.php";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmation);
        getSupportActionBar().setTitle("Récapitulatif");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        confimer=findViewById(R.id.confirmer);
        //TextView db=findViewById(R.id.db);
        TextView df=findViewById(R.id.df);
        TextView db=findViewById(R.id.db);
        //db.setText(getIntent().getExtras().getString("db"));
        df.setText(getIntent().getStringExtra("df"));
        db.setText(getIntent().getStringExtra("db"));
        confimer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent a= new Intent(getApplicationContext(),Bravo.class);

                startActivity(a);
                overridePendingTransition(R.anim.r, R.anim.lf);
            }
        });

    }
    private void reserver()
    {


        final String name= this.name.getText().toString().trim();
        final String email= this.email.getText().toString().trim();
        final String password= this.password.getText().toString().trim();
        final String c_password= this.c_password.getText().toString().trim();
        final String ida="",ide="",db="",df="";

        StringRequest stringRequest= new StringRequest(Request.Method.POST, URL_RESERV, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try{
                    JSONObject jsonObject=new JSONObject (response);
                    String success=jsonObject.getString("success");
                    // Toast.makeText(MainActivity.this, "arriver à success !", Toast.LENGTH_SHORT).show();
                    if(success.equals("1"))
                    {
                        Toast.makeText(Confirmation.this, "Bravo ^^!", Toast.LENGTH_SHORT).show();
                        Intent otherActivity= new Intent(getApplicationContext(),Connexion.class);
                        startActivity(otherActivity);
                        finish();
                    }
   /* if(success.equals("2"))
    {
        Toast.makeText(MainActivity.this, "Erreur dans le code php ou baz !", Toast.LENGTH_SHORT).show();
    }*/
                }catch (JSONException e)
                {
                    e.printStackTrace();
                    Toast.makeText(Confirmation.this, "Erreur exeption!!"+e.toString(), Toast.LENGTH_SHORT).show();

                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(Confirmation.this, "Erreur reponse!!"+error.toString(), Toast.LENGTH_SHORT).show();


            }
        })
        {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("id_annonce", ida);
                params.put("id_client",ide);
                params.put("db",db);
                params.put("df",df);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
}
