package com.anisapp.locationdevoiture;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class File_methodes {

    public File_methodes() {

    }

    public String get_id() {
        String id_client="";
        BufferedReader b = null;
        try {
            b = new BufferedReader(new FileReader("src/data/session.txt"));
        } catch (FileNotFoundException e2) {
            // TODO Auto-generated catch block
            e2.printStackTrace();
        }
        try {
            id_client = b.readLine();
            b.close();
        } catch (IOException e2) {
            // TODO Auto-generated catch block
            e2.printStackTrace();


        }
        return id_client;
    }
        public void set_id(String id){
            try {
                BufferedWriter bi = new BufferedWriter(new FileWriter(new File("ifConnect.txt")));
                bi.write(id);
                bi.close();
            } catch (IOException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }

        }

}