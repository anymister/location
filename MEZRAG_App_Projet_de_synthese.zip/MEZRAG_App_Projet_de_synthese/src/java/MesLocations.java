package com.anisapp.locationdevoiture;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.util.HashMap;
import java.util.Map;

public class MesLocations extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout drawerlayout;
    private ActionBarDrawerToggle mToggle;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mes_locations);
        getSupportActionBar().setTitle("Historique de location");
        drawerlayout=findViewById(R.id.drawerlayout);
        mToggle=new ActionBarDrawerToggle(this, drawerlayout,R.string.open,R.string.close);
        NavigationView navigationView=findViewById(R.id.design_navigation_view);
        navigationView.setNavigationItemSelectedListener(this);
        drawerlayout.addDrawerListener(mToggle);

        mToggle.syncState();
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {
            case R.id.profil:
                Intent otherActivity= new Intent(getApplicationContext(),Profil.class);
                startActivity(otherActivity);
                finish();
                break;
            case R.id.mesLocation:
                Intent location= new Intent(getApplicationContext(),MesLocations.class);
                startActivity(location);
                finish();
                break;
            case R.id.annonces:
                Intent ann= new Intent(getApplicationContext(),MenuPrincipal.class);
                startActivity(ann);
                finish();                break;
            case R.id.mesVoitures:
                Intent mesvoitures= new Intent(getApplicationContext(),MesVoitures.class);
                startActivity(mesvoitures);
                finish();                    break;
            case R.id.DeposerVoiture:
                Intent depot= new Intent(getApplicationContext(),DeposerVoiture.class);
                startActivity(depot);
                finish();                    break;
            case R.id.aide:
                Intent aide= new Intent(getApplicationContext(),Aide.class);
                startActivity(aide);
                finish();                    break;
            case R.id.apropos:
                Intent apropos= new Intent(getApplicationContext(),Apropos.class);
                startActivity(apropos);
                finish();                    break;
            case R.id.deconnexion:
                File_methodes fm=new File_methodes();
                fm.set_id("123456789");
                Intent dec= new Intent(getApplicationContext(),Connexion.class);
                startActivity(dec);
                Toast.makeText(this,"Vous etes déconnecté ^^",Toast.LENGTH_LONG).show();
                finish();                    break;

        }
        drawerlayout.closeDrawer(GravityCompat.START);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if(mToggle.onOptionsItemSelected(item))

        {
            return true;
        }
        return super.onOptionsItemSelected(item);

    }
    public void mes_locations() {

        final String titre= "";
        final String prix= "";
        final String db= "";
        final String df= "";

        StringRequest request=new StringRequest(Request.Method.POST, "https://locationwordpress.000webhostapp.com/sitePHP/appli/mesLocation.php",

                new Response.Listener<String>() {

                    @Override
                    public void onResponse(String response) {

                        if(response=="0") {
                            Toast.makeText(getApplicationContext(),

                                    "Un problème est servenu lors de la connexion au serveur" ,Toast.LENGTH_SHORT).show();
                        }
                        else {
                            File_methodes fkm=new File_methodes();
                            fkm.set_id(response);
                            Toast.makeText(getApplicationContext(),

                                    "Voici votre historique de location :)" ,Toast.LENGTH_SHORT).show();
                            Intent otherActivity= new Intent(getApplicationContext(),MenuPrincipal.class);

                            startActivity(otherActivity);

                            finish();

                        }


                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                // load.setVisibility(View.GONE);
                Toast.makeText(getApplicationContext(),

                        "Une erreur est survenu, veuillez reessayez plus tard !" ,Toast.LENGTH_SHORT).show();

            }
        })
        {
            protected Map<String,String> params=new HashMap<>();

            @Override
            public Map<String, String> getParams() {
                File_methodes f= new File_methodes(); //récupéré l'id du client enregistrer dans le fichier txt après connexion
                String ide =f.get_id();
                params.put("e" +
                        "" +
                        "id_client",ide);//envoyer id du proprietaire au serveur pour récupérer ses voitures


                return  params;
            }
        };

        Volley.newRequestQueue(this).add(request);
    }
}
