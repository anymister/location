package com.anisapp.locationdevoiture.models;

public class HighTechLocations {
    //attributs
    private String name;
    private String memoning;
    private int price;
private Date db;
private Date df;

    //contruct
    public HighTechLocations(String name, String memoning, int price, Date db, Date df){
this.db=db;
this.df=df;
        this.name=name;
        this.price=price;
        this.memoning=memoning;
    }
    //methodes
    public String getMemoning(){
        return memoning;
    }
    public String getName(){ return name;}

    public int getPrice() {
        return price;
    }
public int getDb() {
        return db;
    }
public int getDf() {
        return df;
    }
}
