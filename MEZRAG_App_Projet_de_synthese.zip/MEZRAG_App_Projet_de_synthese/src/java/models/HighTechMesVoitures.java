package com.anisapp.locationdevoiture.models;

public class HighTechMesVoitures {
    //attributs
    private String name;
   
    private int price;
private Date db;
private Date df;

    //contruct
    public HighTechMesVoitures(String name, int price, Date db, Date df){
this.db=db;
this.df=df;
        this.name=name;
        this.price=price;
        this.memoning=memoning;
    }
    //methodes
    public String getMemoning(){
        return memoning;
    }
    public String getName(){ return name;}

    public int getPrice() {
        return price;
    }
public int getDb() {
        return db;
    }
public int getDf() {
        return df;
    }
}
