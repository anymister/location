<?php


 session_start();

 

require_once 'connect.php';

    $sql = "SELECT * FROM annonce";
$result = mysqli_query($conn,$sql);
$rows = array();
while($r = mysqli_fetch_assoc($result)) {
    $rows[] = $r;
   
}
echo json_encode($rows);

  mysqli_close($conn);

    

?>
