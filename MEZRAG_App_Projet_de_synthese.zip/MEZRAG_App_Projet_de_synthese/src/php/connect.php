
<?php
$host_name = 'localhost';

$database = 'id7297248_basesite';

$user_name = 'id7297248_basesite';

$password = 'anis1996';




  $conn = mysqli_connect('localhost','id7297248_basesite','anis1996','id7297248_basesite');

 
?>

