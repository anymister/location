<?php

if($_SERVER['REQUEST_METHOD']=="POST")
{
$matricule=$_POST['matricule'];
$annee=$_POST['annee'];
$prix=$_POST['prix'];
$modele=$_POST['modele'];
$energie=$_POST['energie'];
$db_dispo=$_POST['db_dispo'];
$df_dispo=$_POST['df_dispo'];
$id_client=$_POST['id_client'];

//$password = password_hash($password,PASSWORD_DEFAULT);
require_once 'connect.php';

$sql="INSERT INTO membres(matricule, annee_mise_circulation, prix, modele,kilometrage, energie, date_debut_dispo, date_fin_dispo) VALUES ('$matricule','$annee','$prix','$modele','$kilometrage','$energie','$db_dispo','$df_dispo')";

if(mysqli_query ($conn, $sql) AND isset($email) AND isset($password) AND isset($name))
{
$result["success"] ="1";
$result["message"]="success";

echo json_encode($result);
mysqli_close($conn);

}
else 
{
$result["success"] ="2";
$result["message"]="error";

echo json_encode($result);
mysqli_close($conn);

}

}
?>


