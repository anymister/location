<?php
session_start();

$email =filter_input(INPUT_POST,"email");
$password=filter_input(INPUT_POST,"password");
 
 

require_once 'connect.php';

    $sql = "SELECT * FROM users_table WHERE email='$email' AND password='$password'";

    $result = mysqli_query($conn, $sql);

  $data=mysqli_fetch_array($result);
    
if(($email!=null) AND ($password!=null)){
     if (($data['email']==$email) )
      {
           session_start();
          
         echo $data['id']; 
     }
     else echo '0';
     }
    else echo '0';
 

    

?>
