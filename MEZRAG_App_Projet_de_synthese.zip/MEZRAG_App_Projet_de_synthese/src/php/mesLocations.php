<?php


 //session_start();

 $id=(int)filter_input(INPUT_POST,"idclient");
 //$id=3;
require_once 'connect.php';

    $sql = "SELECT * FROM Contrat_Location WHERE id_client='$id'";
$result = mysqli_query($conn,$sql);
$rows = array();
while($r = mysqli_fetch_assoc($result)) {
    $rows[] = $r;
   // echo $r["description"];
    //echo 'izan';
}
echo json_encode($rows);

  mysqli_close($conn);

    

?>
