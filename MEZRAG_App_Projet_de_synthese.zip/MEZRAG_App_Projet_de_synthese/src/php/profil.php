<?php

$idii=filter_input(INPUT_POST,"idcli");
 //$idii="2018";
 
require_once 'connect.php';



//$id=(int)$_POST['idcli'];
//$id=3;
    $sql = "SELECT * FROM membres WHERE id='$idii'";
$result = mysqli_query($conn,$sql);
$rows = array();
while($r = mysqli_fetch_assoc($result)) {
    $rows[] = $r;
  // echo $r["id"];
    //echo 'izan';
}
echo json_encode($rows);

  mysqli_close($conn);

    

?>
