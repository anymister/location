<?php

if($_SERVER['REQUEST_METHOD']=="POST")
{
$name=$_POST['name'];
$email=$_POST['email'];
$password=$_POST['password'];

//$password = password_hash($password,PASSWORD_DEFAULT);
require_once 'connect.php';

$sql="INSERT INTO membres(pseudo, mail, password) VALUES ('$name','$email','$password')";

if(mysqli_query ($conn, $sql) AND isset($email) AND isset($password) AND isset($name))
{
$result["success"] ="1";
$result["message"]="success";

echo json_encode($result);
mysqli_close($conn);

}
else 
{
$result["success"] ="2";
$result["message"]="error";

echo json_encode($result);
mysqli_close($conn);

}

}
?>


