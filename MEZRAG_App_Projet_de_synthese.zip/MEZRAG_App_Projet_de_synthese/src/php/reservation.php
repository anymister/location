<?php
session_start();

if($_SERVER['REQUEST_METHOD']=="POST")
{
$name=$_POST['date_debut'];
$email=$_POST['date_fin'];
$idc=(int)$_POST['id_client'];
$ida=(int)$_POST['id_annonce'];

require_once 'connect.php';
// selection la matricule 
$sql = "SELECT * FROM annonce WHERE id_annonce='$ida'";

    $result1 = mysqli_query($conn, $sql);

  $data1=mysqli_fetch_array($result1);
      
     $m=$data1['matricule_voiture'];
     $prix=$data1['prix'];

$sql="INSERT INTO Contrat_Location(id_client ,id_annonce ,matricule ,prix ,date_debut ,date_fin) VALUES ($idc,$ida,'22',25.3,'$name','$email')";

if(mysqli_query ($conn, $sql) AND isset($email) AND isset($name))
{
$result["succ"] ="1";
$result["message"]="success";

echo json_encode($result);
mysqli_close($conn);

}
else 
{
$result["succ"] ="2";
$result["message"]="error";

echo json_encode($result);
mysqli_close($conn);

}

}
?>


